This is not mod specific, just a general loot_table datapack that can be applied to vanllia mc or mods: https://www.youtube.com/watch?v=SFOGmKZ-jXs

Loot table generator: https://amaury.carrade.eu/minecraft/loot_tables
			https://misode.github.io/loot-table/